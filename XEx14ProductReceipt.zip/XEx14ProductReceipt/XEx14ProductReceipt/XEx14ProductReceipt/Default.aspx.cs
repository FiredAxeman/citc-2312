﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace XEx14ProductReceipt
{
    public partial class Default : System.Web.UI.Page
    {
        protected void grdProducts_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            if (e.Exception != null)
            {
                lblError.Text = "A error has occured " + e.Exception.Message;
                e.ExceptionHandled = true;
                e.KeepInEditMode = true;
            }
            else if (e.AffectedRows == 0)
            {
                lblError.Text = "Another user may have updated that row. Please try again";
            }
            //Now I did do this, most of this was all copied from the book so I think I did it right but this is my own work.
        }
        
    }
}